import Routes from './routes';
import { ProductionProvider } from './services/production/contexts/production';
import './styles/global.css';

function App() {
  return (
    <ProductionProvider>
      <Routes />
    </ProductionProvider>
  );
}

export default App;
