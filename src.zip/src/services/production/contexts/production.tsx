import { createContext } from 'react';
import { type ReactNode } from 'react';

import { useProduction } from '../hooks/production';

type Production = {
  id: string;
  name: string;
  description?: string;
};

type ProductionState = {
  productions: Production[];
  selectedProduction: Production | null;
  isLoading: boolean;
  error: string | null;
};

interface ProductionContextType extends ProductionState {
  selectProduction: (production: Production) => void;
  deselectProduction: () => void;
}
const ProductionContext = createContext<ProductionContextType | undefined>(undefined);

function ProductionProvider({ children }: { children: ReactNode }) {
  const { state, selectProduction, deselectProduction } = useProduction();

  return (
    <ProductionContext.Provider
      value={{
        ...state,
        selectProduction,
        deselectProduction,
      }}
    >
      {children}
    </ProductionContext.Provider>
  );
}

export { ProductionProvider, ProductionContext };
