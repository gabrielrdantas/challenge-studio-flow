import { useReducer } from 'react';

import { type Production, productionReducer } from '../../reducers/production';

export const useProduction = () => {
  const [state, dispatch] = useReducer(productionReducer);

  const fetchProductions = async () => {
    try {
      dispatch({ type: 'SET_LOADING', payload: true });
      const response = await fetch(`${import.meta.env.VITE_API_URL}/productions`);

      if (!response.ok) {
        throw new Error('Failed to fetch productions');
      }

      const data = await response.json();
      dispatch({ type: 'SET_PRODUCTIONS', payload: data });
    } catch (error) {
      dispatch({
        type: 'SET_ERROR',
        payload: error instanceof Error ? error.message : 'An error occurred',
      });
    } finally {
      dispatch({ type: 'SET_LOADING', payload: false });
    }
  };

  const selectProduction = (production: Production) => {
    dispatch({ type: 'SELECT_PRODUCTION', payload: production });
  };

  const deselectProduction = () => {
    dispatch({ type: 'SELECT_PRODUCTION', payload: initialState.productions[0] });
  };

  return {
    fetchProductions,
    selectProduction,
    deselectProduction,
    productions: state.productions,
    selectedProduction: state.selectedProduction,
    state,
  };
};
